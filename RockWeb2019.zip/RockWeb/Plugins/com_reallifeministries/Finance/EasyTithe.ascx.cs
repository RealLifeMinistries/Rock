﻿using Rock.Attribute;
using Rock.Data;
using Rock.Model;
using Rock.Web.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Rock.Utility;
using System.Net;

namespace com.reallifeministries.Finance
{
    [DisplayName("Easy Tithe Import")]
    [Category("RLM - Finance")]
    [Description("Block used to import Easy Tithe records")]
    [AttributeField(Rock.SystemGuid.EntityType.PERSON, "Envelope Number Attribute", "", true, false, "", "" )]
    [DefinedValueField(Rock.SystemGuid.DefinedType.FINANCIAL_TRANSACTION_TYPE, "Transaction Type", "", true, false, "", "")]
    [DefinedValueField(Rock.SystemGuid.DefinedType.FINANCIAL_SOURCE_TYPE, "Source Type", "", true, false, "", "")]


    public partial class EasyTithe : RockBlock
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                using (RockContext context = new RockContext())
                {
                    var financialBatchService = new FinancialBatchService(context);
                    var batches = financialBatchService.Queryable().OrderByDescending(f => f.CreatedDateTime).ToList();

                    ddlBatch.DataSource = batches;
                    ddlBatch.DataValueField = "GUID";
                    ddlBatch.DataTextField = "Name";

                    ddlBatch.DataBind();
                }
            }
        }

        protected List<EasyTitheModel> GetRecordList()
        {
            var filePath = Server.MapPath("~/Plugins/com_reallifeministries/Finance/csv/");

            fuFile.PostedFile.SaveAs(filePath + fuFile.FileName);

            var list = (from line in File.ReadAllLines(filePath + fuFile.FileName)
                        let columns = line.Split(',')
                        select new EasyTitheModel
                        {
                            EnvelopeNumber = string.IsNullOrEmpty(columns[0]) ? 0 : int.Parse(columns[0]),
                            Amount = decimal.Parse(columns[1]),
                            Date = DateTime.Parse(columns[2]),
                            Fund = int.Parse(columns[3])
                        }).ToList();

            return list;
        }

        #region Button Events
        protected void btnTest_Click(object sender, EventArgs e)
        {
            nbError.Text = "";
            nbError.Visible = false;
            if (fuFile.HasFile)
            {

                var list = GetRecordList();




                var context = new RockContext();
                var attributeValueService = new AttributeValueService(context);
                var attribute = GetEnvelopeAttribute(context);

                List<EasyTitheModel> missingList = new List<EasyTitheModel>();

                foreach (var item in list)
                {
                    if (item.EnvelopeNumber == 0)
                    {
                        missingList.Add(item);
                    }
                    else
                    {
                        var av = attributeValueService.Queryable().Where(a => a.Value == item.EnvelopeNumber.ToString() && a.AttributeId == attribute.Id).FirstOrDefault();

                        if (av == null)
                        {
                            missingList.Add(item);
                        }
                    }

                }

                if (missingList.Count > 0)
                {
                    StringBuilder sb = new StringBuilder();



                    sb.Append("The following envelope numbers are missing");
                    foreach (var item in missingList.GroupBy(m => m.EnvelopeNumber).Select(x => x.First()).ToList())
                    {
                        sb.AppendFormat("<br/>{0}", item.EnvelopeNumber == 0 ? "[blank]" : item.EnvelopeNumber.ToString());
                    }

                    mdMissing.Show();
                    ltrMissing.Text = sb.ToString();
                    context.Dispose();
                    return;
                }
                else
                {
                    mdMissing.Show();
                    ltrMissing.Text = "All records mapped successfully";
                    context.Dispose();
                }
            }

            nbError.Text = "Please select a file";
            nbError.Visible = true;

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            nbError.Text = "";
            nbError.Visible = false;

            if (fuFile.HasFile)
            {
                var list = GetRecordList();

                using (var context = new RockContext())
                {
                    try
                    {
                        FinancialBatchService financialBatchService = new FinancialBatchService(context);
                        DefinedValueService definedValueService = new DefinedValueService(context);
                        AttributeValue av = new AttributeValue();
                        var financialBatch = financialBatchService.Get(Guid.Parse(ddlBatch.SelectedValue));
                        var attributeValueService = new AttributeValueService(context);
                        var attribute = GetEnvelopeAttribute(context);
                        var transactionType = definedValueService.Get(Guid.Parse(GetAttributeValue("TransactionType")));
                        var sourceType = definedValueService.Get(Guid.Parse(GetAttributeValue("SourceType")));
                        

                        if (list.Count > 0)
                        {
                            context.Database.BeginTransaction();
                            FinancialTransactionService financialTransactionService = new FinancialTransactionService(context);
                            FinancialTransactionDetailService finacialTransactionDetailService = new FinancialTransactionDetailService(context);
                            FinancialAccountService financialAccountService = new FinancialAccountService(context);
                            PersonService personService = new PersonService(context);
                            var groupedRecords = list.GroupBy(x => x.EnvelopeNumber).ToList();
                            List<FinancialTransaction> transactionList = new List<FinancialTransaction>();
                            
                            foreach (var record in groupedRecords)
                            {
                                var tran = record.FirstOrDefault();

                                //Get the person with the envelope number
                                av = attributeValueService.Queryable().Where(a => a.Value == tran.EnvelopeNumber.ToString() && a.AttributeId == attribute.Id).FirstOrDefault();

                                if(av != null)
                                {
                                    //if the attribute value exists, first create the financial transaction
                                    var transaction = new FinancialTransaction();
                                    var person = personService.Get(av.EntityId.Value);
                                    transaction.BatchId = financialBatch.Id;
                                    transaction.TransactionDateTime = tran.Date;
                                    transaction.TransactionTypeValueId = transactionType.Id;
                                    transaction.SourceTypeValueId = sourceType.Id;
                                    transaction.CreatedDateTime = DateTime.Now;
                                    transaction.CreatedByPersonAliasId = CurrentPersonAliasId;
                                    transaction.ForeignKey = "Easy Tithe Import";
                                    transaction.AuthorizedPersonAliasId = person.PrimaryAliasId;

                                    if (transaction.IsValid)
                                    {
                                        financialTransactionService.Add(transaction);
                                        context.SaveChanges();
                                    }
                                    

                                    foreach (var item in record)
                                    {
                                        //Insert transaction details
                                        var transactionDetail = new FinancialTransactionDetail();
                                        var account = financialAccountService.Queryable().Where(f => f.ForeignId == item.Fund).FirstOrDefault();
                                        transactionDetail.TransactionId = transaction.Id;
                                        transactionDetail.AccountId = account != null ? account.Id : 1;
                                        transactionDetail.Amount = item.Amount;
                                        transactionDetail.ForeignKey = "Easy Tithe";

                                        if (transactionDetail.IsValid)
                                        {
                                            finacialTransactionDetailService.Add(transactionDetail);
                                            context.SaveChanges();
                                        }
                                    }

                                    transactionList.Add(transaction);
                                }


                            }

                            context.Database.CurrentTransaction.Commit();

                            var csv = new StringBuilder();
                            csv.AppendLine("Person,Amount,AccountId,TransactionId");
                            foreach (var item in transactionList)
                            {
                                foreach (var detail in item.TransactionDetails)
                                {
                                    csv.AppendFormat("{0},{1},{2},{3}", detail.Transaction.AuthorizedPersonAlias.Person.FullName, detail.Amount, detail.AccountId, detail.TransactionId);
                                    csv.Append(System.Environment.NewLine);
                                }
                            }

                            var filePath = Server.MapPath("~/Plugins/com_reallifeministries/Finance/csv/EasyTithe.csv");
                            File.WriteAllText(filePath, csv.ToString());
                            string baseurl = Request.Url.Scheme + "://" + Request.Url.Authority + Request.ApplicationPath.TrimEnd('/') + "/";
                            nbSuccess.Text = String.Format("Records successfully imported. To view the transactions click <a href='{0}' target='_blank'>here</a>", baseurl + "Plugins/com_reallifeministries/Finance/csv/EasyTithe.csv");
                            nbSuccess.Visible = true;



                        }
                        else
                        {
                            context.Database.CurrentTransaction.Rollback();
                            nbError.Text = "File selected contained no records";
                            nbError.Visible = true;
                            return;
                        }
                    }
                    catch (Exception ex)
                    {
                        context.Database.CurrentTransaction.Rollback();
                        nbError.Text = "Error occcurred when trying to import records.";
                        nbError.Visible = true;
                        LogException(ex);
                        throw;
                    }
                    
                }
            }
        }

        #endregion


        public Rock.Model.Attribute GetEnvelopeAttribute(RockContext context)
        {
            var attrGuid = GetAttributeValue("EnvelopeNumberAttribute");
            var attributeService = new AttributeService(context);
            var attribute = attributeService.Get(Guid.Parse(attrGuid));

            return attribute;
        }

        
    }

    public class EasyTitheModel
    {
        public int? EnvelopeNumber { get; set; }
        public decimal Amount { get; set; }
        public DateTime Date { get; set; }
        public int Fund { get; set; }

    }
}

