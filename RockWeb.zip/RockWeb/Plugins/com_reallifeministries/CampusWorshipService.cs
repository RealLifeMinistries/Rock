﻿using Rock.Model;

namespace com.reallifeministries.Attendance
{
    public class CampusWorshipService
    {
        public string Text { get; set; }
        public string WorshipService { get; set; }
        public string Campus { get; set; }
        public string PrayerCategory { get; set; }
    }
}